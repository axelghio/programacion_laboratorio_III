<?php
    if($_GET["nombre"] != null){
        echo "Hola ".$_GET["nombre"];
    }
    else{
        echo ":c";
    }