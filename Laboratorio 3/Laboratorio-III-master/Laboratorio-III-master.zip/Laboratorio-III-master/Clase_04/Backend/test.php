<?php
    echo "Hola mundo";