Bootstrap uses [GitHub's Releases feature](https://blog.github.com/2013-07-02-release-your-software/) for its changelogs.

See [the Releases section of our GitHub project](https://github.com/twbs/bootstrap/releases) for changelogs for each release version of Bootstrap.

Release announcement posts on [the official Bootstrap blog](https://blog.getbootstrap.com/) contain summaries of the most noteworthy changes made in each release.
