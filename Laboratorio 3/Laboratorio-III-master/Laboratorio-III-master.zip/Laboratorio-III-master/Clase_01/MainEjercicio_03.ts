
Mostrar(5, "Hola");
