var meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
var cont = 0;
for (var i = 0; i < meses.length; i++) {
    cont++;
    console.log(meses[i] + ' ' + cont);
}
