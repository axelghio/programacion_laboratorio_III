"use strict";
var saludo = "HOLA MUNDO!!!";
var simple = 'Puedo mostrar comillas simples';
var dobles = "Puedo mostrar comillas dobles";
console.log(saludo + " \n " + simple + " \n " + dobles);
//# sourceMappingURL=Ejercicio_01.js.map