var nombre : string = "Thomas";
var apellido : string = `Rosas`;
console.log(nombre + ' ' + apellido);
