"use strict";
var nombre = "Thomas";
var apellido = "Rosas";
console.log(nombre + ' ' + apellido);
//# sourceMappingURL=Inicio.js.map