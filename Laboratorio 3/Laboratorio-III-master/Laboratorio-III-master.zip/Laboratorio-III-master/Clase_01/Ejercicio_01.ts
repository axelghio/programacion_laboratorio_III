var saludo : string = "HOLA MUNDO!!!";
var simple : string = 'Puedo mostrar comillas simples';
var dobles : string = "Puedo mostrar comillas dobles";

console.log(`${saludo} \n ${simple} \n ${dobles}`);
