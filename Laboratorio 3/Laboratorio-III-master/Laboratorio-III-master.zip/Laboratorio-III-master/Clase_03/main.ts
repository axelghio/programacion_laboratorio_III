///<reference path="Clases/Empleado.ts" />

let p1 = new Entidades.Empleado("Carlos", "Nuñez", 42494208, "M", 101, 30000);
console.log(p1.Hablar("Ingles"));
console.log(p1.ToString());